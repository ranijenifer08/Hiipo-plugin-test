<?php
/*
Plugin Name: HippoAPI
Plugin URI: http://demo.webbazaar.co.in/ecommerce
Description: Hippo API Contact Form to submit dataso on backend and fetch the API details
Version: 1.0
Author: Rani Jenifer
Author URI: http://demo.webbazaar.co.in/ecommerce
License: GPLv2 or later
Text Domain: HippoAPI
*/

add_action('admin_menu', 'hippo_admin_menu'); //
define('HIPPOROOTDIR', plugin_dir_path(__FILE__)); // plugin path
function hippo_admin_menu()
{

add_menu_page('hippo_form',  //Page Title
              'hippo_form',  //Menu Title
              'manage_options', //Capabilities required for this menu
              'hippo_form-slug', //Menu slug shows on the url
              'hippo_form_list'); //Output of this function will show on the menu page.
              
add_submenu_page('hippo_form-slug', // main menu URL
                    'Edit', // Page title
                    'Edit', // Menu Name
                    'manage_options', // Manging
                    'hippoedit-slug', // URL
                    'hippoedit_list' ); // function name
                    
                    

}
    function hippoedit_list() // Submenu(Edit) menu/ Page function
{
  
   
   include_once HIPPOROOTDIR . '/process/hippo-edit.php';
                
}

function hippo_form_list() // Submenu(Add New) menu/ Page function
{
    if ( isset( $_POST['btn-submit'] ) ){
         global $wpdb;
         
         
         global $wp;

       /*  $url = 'https://jsonplaceholder.typicode.com/users';
    
    $arguments = array(
        'method' => 'GET'
    );

	$response = wp_remote_get( $url, $arguments );


	if ( is_wp_error( $response ) ) {
		$error_message = $response->get_error_message();
		return "Something went wrong: $error_message";
	} else {
		echo '<pre>';
		
		var_dump( wp_remote_retrieve_body( $response->username ) );
		echo '</pre>';
	
	}*/
	
	$data =json_decode(file_get_contents('https://api.staging.myhippo.io/v1/herd/quote?auth_token=zcXbR1NoE0zoozyuqAa75s5gBATbeiUsbkGhvb5toGiNWUdDjIUkAU5XgDwCRTet&street=435%20Homer%20Ave&city=Palo%20Alto&state=CA&zip=94301&first_name=John&last_name=Gill&email=Test%40test.com&phone=7869885582&date_of_birth=05061979'));
	
		?>
	
		<h1 class="quote" style="background: #009ee2d9;
    display: flex;
    justify-content: center;
    margin: 50px;
    padding: 20px;
    align-content: center;
    align-items: center;">Quote Premium
		<?php
		print_r($data->quote_premium); ?></h1>
		
		<?php
	
	
         
      //   add_action('btn-submit','hippoedit_list');

  $tablename=$wpdb->prefix.'hippoapiform';
          $data=array(
        'fname' => $_POST['fname'],
        'mname' => $_POST['mname'],
        'lname' => $_POST['lname'],
         'street' => $_POST['street'],
         'unit' => $_POST['unit'],
         'city' => $_POST['city'],
         'state' => $_POST['state'],
         'zipcode' => $_POST['zipcode'],
         'dob' => $_POST['dob'],
         'pno' => $_POST['pno'],
         
        'email' => $_POST['email'],
        'houseplan' => $_POST['houseplan']);
        
        
    $wpdb->insert( $tablename, $data);
    ?>
  
    <script>
    const api_url = 'https://api.staging.myhippo.io/v1/herd/quote?auth_token=zcXbR1NoE0zoozyuqAa75s5gBATbeiUsbkGhvb5toGiNWUdDjIUkAU5XgDwCRTet&street=435%20Homer%20Ave&city=Palo%20Alto&state=CA&zip=94301&first_name=John&last_name=Gill&email=Test%40test.com&phone=7869885582&date_of_birth=05061979';
        async function getapi()
        
        
        {
               var headers = {}
               
            const response = await fetch(api_url,  {
    method : "GET",
        mode: 'cors',
        headers: headers
});
            const data = await response.json();
            for(i=0;i>data.length;i=i+1)
  {
    console.log(data[i].quote_premium)
  }
        }
        getapi();
        
    </script> 



    <?php
   // echo '<script>alert("Datas Inserted into Database Succesfully")</script>';
    require_once(HIPPOROOTDIR . 'admin/hippo-edit.php');
define("NEXT_PLUGIN_DIR_PATH",plugin_dir_path(__FILE__));

    }
    ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

 <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> 
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="//cdn.datatables.net/1.10.7/js/jquery.dataTables.min.js"></script>
<script src="//cdn.datatables.net/plug-ins/1.10.7/integration/bootstrap/3/dataTables.bootstrap.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
.form-group {
    margin-bottom: 15px;
    
    display: block;
    margin-right: 20px;
    width: 32.3%;
    float: left;
        padding-bottom: 30px !important;
        padding-top: 30px !important;
}
h4 {
    text-align: center;
    font-weight: bold;
}
.btn-info {
    margin-top: 70px;
    width: 35%;
    background-color: #06C22D !important;
    margin-bottom: 30px !important;
     display: inline-block;
}

.formlabel {
    display: block;
    
    height: 30%;
}
 .formfields.hipporadio span {
    display: flex;
}
i.fa.fa-home.ho5 {
    font-size: 50px;
    color: #8672DC;
    padding-right: 5px;
}
i.fa.fa-home.condo {
    font-size: 50px;
    color: #f25642;
}
i.fa.fa-home.house {
    font-size: 50px;
    color: #009EE2;
    padding-right: 5px;
}
.form-group.row.adn {
    width: 49%;
}
input.form-control.adnfield {
    width: 100% !important;
}

.form-control {
    border-bottom: 1px solid #000 !important;
    border-top: none !important;
    box-shadow: none !important;
    border-left: none;
    border-right: none;
}

.adnfield
{
		width: 55% !important;
}

.sub-btn {
    display: table;
    margin: 0 auto;
    text-align: center;
    width: 50%;
}
</style>


<?php


wp_register_plugin_realpath( "' . dirname(__FILE__) . '/process/hippo-edit.php");

//include_once( $symlinked_plugin );?>

 <div class="mypanel"></div>
<div class="hippo_form">



<h4 style="color: #4f57ae;">Hippo API Form</h3>
   <form class="form_add" action="" method="POST" target='_blank' enctype='multipart/form-data'>
       <div class="hippo_form">
   <div class="form-group row">
      <div class="formlabel">
        <label>First Name*</label>
      </div>
      <div class="formfields">
          <input type="text" class="form-control" name="fname" required>
      </div>
   </div>

   <div class="form-group row">
      <div class="formlabel">
        <label>Middle Name</label>
      </div>
      <div class=formfields">
          <input type="text" class="form-control" name="mname">
      </div>
   </div>

      <div class="form-group row">
      <div class="formlabel">
        <label>Last Name*</label>
      </div>
      <div class="formfields">
          <input type="text" class="form-control" name="lname" required>
      </div>
      </div>
      
          <div class="form-group row adn">
      <div class="formlabel">
        <label>Street Adress*</label>
      </div>
      <div class="formfields">
          <input type="text" class="form-control adnfield" name="street" required>
      </div>
      </div>
      
            <div class="form-group row adn">
      <div class="formlabel">
        <label>Unit#</label>
      </div>
      <div class="formfields">
          <input type="text" class="form-control adnfield" name="unit">
      </div>
      </div>


            <div class="form-group row">
      <div class="formlabel">
        <label>City*</label>
      </div>
      <div class="formfields">
          <input type="text" class="form-control" name="city" required>
      </div>
   </div>
   
   
        <div class="form-group row">
      <div class="formlabel">
        <label>State*</label>
      </div>
      <div class="formfields">
          <select name="state" id="state" class="form-control" required>
          <option selected="true" disabled="disabled"></option>    
<option value="Andhra Pradesh">Andhra Pradesh</option>
<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
<option value="Arunachal Pradesh">Arunachal Pradesh</option>
<option value="Assam">Assam</option>
<option value="Bihar">Bihar</option>
<option value="Chandigarh">Chandigarh</option>
<option value="Chhattisgarh">Chhattisgarh</option>
<option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
<option value="Daman and Diu">Daman and Diu</option>
<option value="Delhi">Delhi</option>
<option value="Lakshadweep">Lakshadweep</option>
<option value="Puducherry">Puducherry</option>
<option value="Goa">Goa</option>
<option value="Gujarat">Gujarat</option>
<option value="Haryana">Haryana</option>
<option value="Himachal Pradesh">Himachal Pradesh</option>
<option value="Jammu and Kashmir">Jammu and Kashmir</option>
<option value="Jharkhand">Jharkhand</option>
<option value="Karnataka">Karnataka</option>
<option value="Kerala">Kerala</option>
<option value="Madhya Pradesh">Madhya Pradesh</option>
<option value="Maharashtra">Maharashtra</option>
<option value="Manipur">Manipur</option>
<option value="Meghalaya">Meghalaya</option>
<option value="Mizoram">Mizoram</option>
<option value="Nagaland">Nagaland</option>
<option value="Odisha">Odisha</option>
<option value="Punjab">Punjab</option>
<option value="Rajasthan">Rajasthan</option>
<option value="Sikkim">Sikkim</option>
<option value="Tamil Nadu">Tamil Nadu</option>
<option value="Telangana">Telangana</option>
<option value="Tripura">Tripura</option>
<option value="Uttar Pradesh">Uttar Pradesh</option>
<option value="Uttarakhand">Uttarakhand</option>
<option value="West Bengal">West Bengal</option>
</select>
      </div>
   </div>
   
   
     <div class="form-group row">
      <div class="formlabel">
        <label>Zipcode*</label>
      </div>
      <div class="formfields">
          <input type="text" class="form-control" name="zipcode" required>
      </div>
      </div>
   
            <div class="form-group row">
      <div class="formlabel">
        <label>Data of Birth*</label>
      </div>
      <div class="formfields">
          <input type="text" class="form-control" name="dob" placeholder="MM/DD/YYYY" required>
      </div>
      </div>
   
      <div class="form-group row">
      <div class="formlabel">
        <label>Phone Number*</label>
      </div>
      <div class="formfields">
          <input type="text" class="form-control" name="pno" required>
      </div>
      </div>
   
      <div class="form-group row">
      <div class="formlabel">
        <label>Email*</label>
      </div>
      <div class="formfields">
          <input type="email" class="form-control" name="email" required>
      </div>
   </div>
   
   <div class="row">
    
      <div class="formlabel">
        <label>Is this a House Condo or Ho5</label>
      </div>
      <div class="formfields hipporadio">
          <span class="col-sm-4 col-xs-12">
    <i class="fa fa-home house"></i>
          <input type="radio" id="home" name="houseplan" value="House">
<label for="house"><span class="radiohead">House</span>This may be a single family home, town house or duplex you own and livi in</label></span>
              <span class="col-sm-4 col-xs-12">
    
<i class="fa fa-home condo"></i><input type="radio" id="condo" class="col-sm-4 col-xs-12" name="houseplan" value="condo">
    <label for="condo"><span class="radiohead">Condo</span>This is likely a multi family building or complex in shich you own unit</label></span>
<span class="col-sm-4 col-xs-12"><input type="radio" id="ho" name="houseplan" value="HO5">
<i class="fa fa-home ho5"></i>
    <label for="ho5"><span class="radiohead">HO5</span>
    This Ho5 is open perils insurance policy for a single family home or duplax</label></span></div>
      </div><Br>
   
<div class="sub-btn">

<button class="btn btn-info" type="submit" name="btn-submit">Submit</button>
</div>

</div>
   </form>
</div>
<?php
  global $hippo_db_version;
$hippo_db_version = '1.0';
}
function hippo_install() {
  global $wpdb;
  global $hippo_db_version;

  $table_name = $wpdb->prefix . 'hippoapiform';
  
  $charset_collate = $wpdb->get_charset_collate();

  $sql = "CREATE TABLE $table_name (
    id mediumint(9) NOT NULL AUTO_INCREMENT,
    fname text,
    mname text,
    lname text,
    street text,
   unit text,
    city text,
    state text,
    zipcode mediumint(6) NOT NULL,
    dob int NOT NULL,
    pno mediumint(10) NOT NULL,
    email text,
    houseplan text,
    
    PRIMARY KEY  (id)
  ) $charset_collate;";

  require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
  dbDelta( $sql );

  add_option( 'hippo_db_version', $hippo_db_version );
}

register_activation_hook( __FILE__, 'hippo_install' );
register_activation_hook( __FILE__, 'hippo_install_data' );

add_shortcode('hippo_form','hippo_form_list');




